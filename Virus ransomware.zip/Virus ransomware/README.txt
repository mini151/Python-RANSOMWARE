Thanks for downloading my project 
To encrypt files run ENCRYPT.py
To decrypt files run DECRYPT.py
Bugs or errors?
Send me e-mail
My e-mail mini35372@gmail.com
GOOD LUCK
